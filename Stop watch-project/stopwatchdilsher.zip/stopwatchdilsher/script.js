let startTime = 0;
let elapsedTime = 0;
let timerInterval;
let running = false;

const display = document.getElementById("display");
const startStopBtn = document.getElementById("startStopBtn");
const resetBtn = document.getElementById("resetBtn");
const lapBtn = document.getElementById("lapBtn");
const lapsContainer = document.getElementById("laps");

// ⏱ Format time as HH:MM:SS
function formatTime(ms) {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, "0");
  const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${hours}:${minutes}:${seconds}`;
}

// 🟢 Start the stopwatch
function startTimer() {
  startTime = Date.now() - elapsedTime;
  timerInterval = setInterval(() => {
    elapsedTime = Date.now() - startTime;
    display.textContent = formatTime(elapsedTime);
  }, 100);
  startStopBtn.textContent = "Stop";
  running = true;
}

// 🔴 Stop the stopwatch
function stopTimer() {
  clearInterval(timerInterval);
  startStopBtn.textContent = "Start";
  running = false;
}

// ♻️ Reset stopwatch and laps
function resetTimer() {
  clearInterval(timerInterval);
  elapsedTime = 0;
  display.textContent = "00:00:00";
  lapsContainer.innerHTML = "";
  startStopBtn.textContent = "Start";
  running = false;
}

// 🏁 Record lap
function recordLap() {
  if (!running) return;
  const lapItem = document.createElement("li");
  lapItem.textContent = `Lap ${lapsContainer.children.length + 1}: ${formatTime(elapsedTime)}`;
  lapsContainer.appendChild(lapItem);
}

// Event listeners
startStopBtn.addEventListener("click", () => {
  if (!running) {
    startTimer();
  } else {
    stopTimer();
  }
});

resetBtn.addEventListener("click", resetTimer);
lapBtn.addEventListener("click", recordLap);
